<p class="red">Insert Logo & Co. Info Here as jpeg.  Try to keep it no more than 1.5” tall to preserve the formatting – delete this text before inserting logo</p>
<h1 style="vertical-align: middle">FIELD WORK ORDER</h1>
<p>Date: </p>
<table>
 <tr>
		<td width=300>PROPOSAL SUBMITTED TO </td>
		<td width=300>
			<table>
				<tr>
					<td>PRIMARY PHONE </td>
					<td>ALTERNATE PHONE </td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width=300>&nbsp; </td>
		<td width=300>
      	<table>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
		</table>
		</td>
	</tr>
    <tr>
		<td width=300>ADDRESS </td>
      	<td width=300>EMAIL </td>
	</tr> 
	<tr>
		<td width=300>&nbsp;</td>
      	<td width=300 >&nbsp;</td>
	</tr>
	<tr>
		<td width=300>CITY,  STATE , AND ZIP CODE</td>
      	<td width=300>JOB NAME AND ADDRESS (if different)</td>
	</tr>
	<tr>
		<td width=300>&nbsp;</td>
      	<td width=300>&nbsp;</td>
	</tr>
</table>
<h2 style="text-decoration: underline;">DETAILS:</h2>
<p style="vertical-align: right"><strong>Total hours:<strong></p>
<p>Respectfully Submitted by: </p>
